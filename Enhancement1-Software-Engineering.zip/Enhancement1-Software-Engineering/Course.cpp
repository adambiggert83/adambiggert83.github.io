#include "Course.h"
#include <utility>

Course::Course(std::string number, std::string title, std::vector<std::string> prereqs)
    : courseNumber(std::move(number)), courseTitle(std::move(title)), prerequisites(std::move(prereqs)) {}

const std::string& Course::getNumber() const {
    return courseNumber;
}

const std::string& Course::getTitle() const {
    return courseTitle;
}

const std::vector<std::string>& Course::getPrerequisites() const {
    return prerequisites;
}

#ifndef COURSE_H
#define COURSE_H

#include <string>
#include <vector>

/**
 * Represents a single academic course and its prerequisite course numbers.
 */
class Course {
public:
    Course() = default;
    Course(std::string number, std::string title, std::vector<std::string> prereqs = {});

    const std::string& getNumber() const;
    const std::string& getTitle() const;
    const std::vector<std::string>& getPrerequisites() const;

private:
    std::string courseNumber;
    std::string courseTitle;
    std::vector<std::string> prerequisites;
};

#endif

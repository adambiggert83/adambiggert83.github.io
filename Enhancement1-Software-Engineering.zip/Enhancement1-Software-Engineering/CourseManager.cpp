#include "CourseManager.h"
#include "StringUtils.h"
#include <algorithm>
#include <sstream>

void CourseManager::clear() {
    courseTable.clear();
}

void CourseManager::addCourse(const Course& course) {
    courseTable[course.getNumber()] = course;
}

bool CourseManager::empty() const {
    return courseTable.empty();
}

bool CourseManager::containsCourse(const std::string& courseNumber) const {
    return courseTable.find(StringUtils::toUpper(courseNumber)) != courseTable.end();
}

std::optional<Course> CourseManager::findCourse(const std::string& courseNumber) const {
    auto normalized = StringUtils::toUpper(StringUtils::trim(courseNumber));
    auto iterator = courseTable.find(normalized);

    if (iterator == courseTable.end()) {
        return std::nullopt;
    }

    return iterator->second;
}

std::vector<Course> CourseManager::getCoursesSorted() const {
    std::vector<Course> courses;
    courses.reserve(courseTable.size());

    for (const auto& entry : courseTable) {
        courses.push_back(entry.second);
    }

    std::sort(courses.begin(), courses.end(), [](const Course& left, const Course& right) {
        return left.getNumber() < right.getNumber();
    });

    return courses;
}

std::vector<std::string> CourseManager::validatePrerequisites() const {
    std::vector<std::string> warnings;

    for (const auto& entry : courseTable) {
        const Course& course = entry.second;
        for (const std::string& prerequisite : course.getPrerequisites()) {
            if (!containsCourse(prerequisite)) {
                warnings.push_back(course.getNumber() + " references missing prerequisite " + prerequisite + ".");
            }
        }
    }

    std::sort(warnings.begin(), warnings.end());
    return warnings;
}

std::string CourseManager::buildAdvisingSummary(const std::string& courseNumber) const {
    std::ostringstream output;
    auto course = findCourse(courseNumber);

    if (!course.has_value()) {
        return "Course not found. Please verify the course number and try again.";
    }

    output << "Advising Summary for " << course->getNumber() << "\n";
    output << "Course Title: " << course->getTitle() << "\n";

    if (course->getPrerequisites().empty()) {
        output << "Prerequisites: None listed.\n";
        output << "Advising Note: This course may be available without listed prerequisites.\n";
        return output.str();
    }

    output << "Prerequisites:\n";
    for (const std::string& prerequisite : course->getPrerequisites()) {
        output << "  - " << prerequisite;
        auto prerequisiteCourse = findCourse(prerequisite);
        if (prerequisiteCourse.has_value()) {
            output << ": " << prerequisiteCourse->getTitle();
        } else {
            output << " (warning: prerequisite not found in current catalog)";
        }
        output << "\n";
    }

    output << "Advising Note: Review these prerequisites before registration to support informed course planning.\n";
    return output.str();
}

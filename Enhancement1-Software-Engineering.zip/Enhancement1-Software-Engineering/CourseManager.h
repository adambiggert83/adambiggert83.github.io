#ifndef COURSE_MANAGER_H
#define COURSE_MANAGER_H

#include "Course.h"
#include <optional>
#include <string>
#include <unordered_map>
#include <vector>

/**
 * Encapsulates course storage and course-related operations.
 * This replaces the global course table used in the original artifact.
 */
class CourseManager {
public:
    void clear();
    void addCourse(const Course& course);
    bool empty() const;
    bool containsCourse(const std::string& courseNumber) const;

    std::optional<Course> findCourse(const std::string& courseNumber) const;
    std::vector<Course> getCoursesSorted() const;
    std::vector<std::string> validatePrerequisites() const;
    std::string buildAdvisingSummary(const std::string& courseNumber) const;

private:
    std::unordered_map<std::string, Course> courseTable;
};

#endif

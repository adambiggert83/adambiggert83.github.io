#include "FileLoader.h"
#include "StringUtils.h"
#include <fstream>

bool FileLoader::loadCoursesFromCsv(const std::string& filename, CourseManager& manager, std::vector<std::string>& messages) const {
    std::ifstream file(filename);
    std::string line;
    int lineNumber = 0;
    int loadedCount = 0;

    messages.clear();

    if (!file.is_open()) {
        messages.push_back("Error: Could not open file '" + filename + "'.");
        return false;
    }

    manager.clear();

    while (std::getline(file, line)) {
        ++lineNumber;
        std::vector<std::string> tokens = StringUtils::split(line, ',');

        if (tokens.size() < 2 || tokens[0].empty() || tokens[1].empty()) {
            messages.push_back("Warning: Skipped malformed row " + std::to_string(lineNumber) + ".");
            continue;
        }

        std::vector<std::string> prerequisites;
        for (size_t i = 2; i < tokens.size(); ++i) {
            if (!tokens[i].empty()) {
                prerequisites.push_back(StringUtils::toUpper(tokens[i]));
            }
        }

        Course course(StringUtils::toUpper(tokens[0]), tokens[1], prerequisites);
        manager.addCourse(course);
        ++loadedCount;
    }

    messages.push_back("Data loaded successfully. " + std::to_string(loadedCount) + " course(s) imported.");

    std::vector<std::string> prerequisiteWarnings = manager.validatePrerequisites();
    messages.insert(messages.end(), prerequisiteWarnings.begin(), prerequisiteWarnings.end());

    return loadedCount > 0;
}

#ifndef FILE_LOADER_H
#define FILE_LOADER_H

#include "CourseManager.h"
#include <string>
#include <vector>

/**
 * Handles course file loading and input validation.
 */
class FileLoader {
public:
    bool loadCoursesFromCsv(const std::string& filename, CourseManager& manager, std::vector<std::string>& messages) const;
};

#endif

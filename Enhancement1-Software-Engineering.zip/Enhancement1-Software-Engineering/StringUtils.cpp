#include "StringUtils.h"
#include <algorithm>
#include <cctype>
#include <sstream>

namespace StringUtils {
    std::vector<std::string> split(const std::string& line, char delimiter) {
        std::vector<std::string> tokens;
        std::string token;
        std::stringstream stream(line);

        while (std::getline(stream, token, delimiter)) {
            tokens.push_back(trim(token));
        }

        return tokens;
    }

    std::string trim(const std::string& value) {
        auto first = std::find_if_not(value.begin(), value.end(), [](unsigned char ch) {
            return std::isspace(ch);
        });

        auto last = std::find_if_not(value.rbegin(), value.rend(), [](unsigned char ch) {
            return std::isspace(ch);
        }).base();

        if (first >= last) {
            return "";
        }

        return std::string(first, last);
    }

    std::string toUpper(std::string value) {
        std::transform(value.begin(), value.end(), value.begin(), [](unsigned char ch) {
            return static_cast<char>(std::toupper(ch));
        });
        return value;
    }
}

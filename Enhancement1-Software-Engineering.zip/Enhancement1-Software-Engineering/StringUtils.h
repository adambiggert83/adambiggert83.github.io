#ifndef STRING_UTILS_H
#define STRING_UTILS_H

#include <string>
#include <vector>

namespace StringUtils {
    std::vector<std::string> split(const std::string& line, char delimiter);
    std::string trim(const std::string& value);
    std::string toUpper(std::string value);
}

#endif

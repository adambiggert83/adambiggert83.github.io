#include "MenuSystem.h"
#include "StringUtils.h"
#include <iostream>
#include <limits>
#include <string>
#include <vector>

void MenuSystem::run() {
    std::cout << "Welcome to the enhanced course planner.\n";

    int choice = 0;
    do {
        std::cout << "\n1. Load Data Structure\n"
                  << "2. Print Course List\n"
                  << "3. Print Course\n"
                  << "4. Print Advising Summary\n"
                  << "5. Display Full Prerequisite Path\n"
                  << "6. Check Circular Dependencies\n"
                  << "9. Exit\n"
                  << "What would you like to do? ";

        choice = getMenuChoice();

        switch (choice) {
            case 1:
                loadData();
                break;
            case 2:
                printCourseList();
                break;
            case 3:
                printCourseDetails();
                break;
            case 4:
                printAdvisingSummary();
                break;
            case 5:
                printPrerequisitePath();
                break;
            case 6:
                checkCircularDependencies();
                break;
            case 9:
                std::cout << "Thank you for using the course planner!\n";
                break;
            default:
                std::cout << choice << " is not a valid option. Please select 1, 2, 3, 4, 5, 6, or 9.\n";
        }
    } while (choice != 9);
}

int MenuSystem::getMenuChoice() const {
    int choice = 0;

    while (!(std::cin >> choice)) {
        std::cout << "Invalid input. Please enter a numeric menu option.\n";
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "What would you like to do? ";
    }

    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    return choice;
}

void MenuSystem::loadData() {
    std::string filename;
    std::vector<std::string> messages;

    std::cout << "Enter file name: ";
    std::getline(std::cin, filename);
    filename = StringUtils::trim(filename);

    if (filename.empty()) {
        std::cout << "Error: File name cannot be empty.\n";
        return;
    }

    fileLoader.loadCoursesFromCsv(filename, courseManager, messages);

    for (const std::string& message : messages) {
        std::cout << message << "\n";
    }
}

void MenuSystem::printCourseList() const {
    if (courseManager.empty()) {
        std::cout << "No data loaded. Please load the file first.\n";
        return;
    }

    std::cout << "Here is the course schedule:\n";
    for (const Course& course : courseManager.getCoursesSorted()) {
        std::cout << course.getNumber() << ", " << course.getTitle() << "\n";
    }
}

void MenuSystem::printCourseDetails() const {
    if (courseManager.empty()) {
        std::cout << "No data loaded. Please load the file first.\n";
        return;
    }

    std::string courseNumber;
    std::cout << "What course do you want to know about? ";
    std::getline(std::cin, courseNumber);

    auto course = courseManager.findCourse(courseNumber);
    if (!course.has_value()) {
        std::cout << "Course not found. Please verify the course number and try again.\n";
        return;
    }

    std::cout << course->getNumber() << ", " << course->getTitle() << "\n";

    if (course->getPrerequisites().empty()) {
        std::cout << "Prerequisites: None\n";
        return;
    }

    std::cout << "Prerequisites: ";
    for (size_t i = 0; i < course->getPrerequisites().size(); ++i) {
        std::cout << course->getPrerequisites()[i];
        if (i < course->getPrerequisites().size() - 1) {
            std::cout << ", ";
        }
    }
    std::cout << "\n";
}

void MenuSystem::printAdvisingSummary() const {
    if (courseManager.empty()) {
        std::cout << "No data loaded. Please load the file first.\n";
        return;
    }

    std::string courseNumber;
    std::cout << "Enter a course number for the advising summary: ";
    std::getline(std::cin, courseNumber);

    std::cout << courseManager.buildAdvisingSummary(courseNumber);
}


void MenuSystem::printPrerequisitePath() const {
    if (courseManager.empty()) {
        std::cout << "No data loaded. Please load the file first.\n";
        return;
    }

    std::string courseNumber;
    std::cout << "Enter a course number to analyze its full prerequisite path: ";
    std::getline(std::cin, courseNumber);

    GraphAnalyzer analyzer(courseManager);
    std::cout << analyzer.buildPrerequisitePath(courseNumber);
}

void MenuSystem::checkCircularDependencies() const {
    if (courseManager.empty()) {
        std::cout << "No data loaded. Please load the file first.\n";
        return;
    }

    GraphAnalyzer analyzer(courseManager);
    std::vector<std::string> warnings = analyzer.findAllCircularDependencies();

    if (warnings.empty()) {
        std::cout << "No circular prerequisite dependencies were detected.\n";
        return;
    }

    for (const std::string& warning : warnings) {
        std::cout << warning << "\n";
    }
}

#ifndef MENU_SYSTEM_H
#define MENU_SYSTEM_H

#include "CourseManager.h"
#include "FileLoader.h"
#include "GraphAnalyzer.h"

/**
 * Manages console input/output and delegates business logic to other classes.
 */
class MenuSystem {
public:
    void run();

private:
    CourseManager courseManager;
    FileLoader fileLoader;

    int getMenuChoice() const;
    void loadData();
    void printCourseList() const;
    void printCourseDetails() const;
    void printAdvisingSummary() const;
    void printPrerequisitePath() const;
    void checkCircularDependencies() const;
};

#endif

#!/bin/bash
g++ -std=c++17 main.cpp Course.cpp CourseManager.cpp FileLoader.cpp MenuSystem.cpp StringUtils.cpp GraphAnalyzer.cpp -o CoursePlanner

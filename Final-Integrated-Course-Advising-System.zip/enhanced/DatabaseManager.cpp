#include "DatabaseManager.h"
#include "StringUtils.h"
#include <utility>

DatabaseManager::DatabaseManager(std::string databaseFile)
    : databaseFile(std::move(databaseFile)), database(nullptr) {}

DatabaseManager::~DatabaseManager() {
    close();
}

bool DatabaseManager::open(std::vector<std::string>& messages) {
    if (database != nullptr) {
        return true;
    }

    if (sqlite3_open(databaseFile.c_str(), &database) != SQLITE_OK) {
        messages.push_back("Database error: Could not open SQLite database '" + databaseFile + "'.");
        close();
        return false;
    }

    return executeStatement("PRAGMA foreign_keys = ON;", messages);
}

void DatabaseManager::close() {
    if (database != nullptr) {
        sqlite3_close(database);
        database = nullptr;
    }
}

bool DatabaseManager::initializeSchema(std::vector<std::string>& messages) {
    if (!open(messages)) {
        return false;
    }

    const std::string createCoursesTable =
        "CREATE TABLE IF NOT EXISTS Courses ("
        "courseNumber TEXT PRIMARY KEY, "
        "courseTitle TEXT NOT NULL"
        ");";

    const std::string createPrerequisitesTable =
        "CREATE TABLE IF NOT EXISTS Prerequisites ("
        "courseNumber TEXT NOT NULL, "
        "prerequisiteNumber TEXT NOT NULL, "
        "PRIMARY KEY(courseNumber, prerequisiteNumber), "
        "FOREIGN KEY(courseNumber) REFERENCES Courses(courseNumber) ON DELETE CASCADE"
        ");";

    return executeStatement(createCoursesTable, messages)
        && executeStatement(createPrerequisitesTable, messages);
}

bool DatabaseManager::saveCourses(const CourseManager& manager, std::vector<std::string>& messages) {
    if (manager.empty()) {
        messages.push_back("No course data is loaded. Load CSV data before saving to the database.");
        return false;
    }

    if (!initializeSchema(messages)) {
        return false;
    }

    if (!executeStatement("BEGIN TRANSACTION;", messages)) {
        return false;
    }

    bool success = executeStatement("DELETE FROM Prerequisites;", messages)
        && executeStatement("DELETE FROM Courses;", messages);

    for (const Course& course : manager.getCoursesSorted()) {
        if (!success) {
            break;
        }
        success = upsertCourse(course, messages);
    }

    if (success) {
        success = executeStatement("COMMIT;", messages);
        if (success) {
            messages.push_back("Database save completed successfully.");
        }
    } else {
        executeStatement("ROLLBACK;", messages);
        messages.push_back("Database save failed. Transaction rolled back.");
    }

    return success;
}

bool DatabaseManager::loadCourses(CourseManager& manager, std::vector<std::string>& messages) {
    if (!initializeSchema(messages)) {
        return false;
    }

    CourseManager loadedManager;
    const char* courseSql = "SELECT courseNumber, courseTitle FROM Courses ORDER BY courseNumber;";
    sqlite3_stmt* courseStatement = nullptr;

    if (sqlite3_prepare_v2(database, courseSql, -1, &courseStatement, nullptr) != SQLITE_OK) {
        messages.push_back("Database error: Could not prepare course query.");
        return false;
    }

    while (sqlite3_step(courseStatement) == SQLITE_ROW) {
        std::string courseNumber = reinterpret_cast<const char*>(sqlite3_column_text(courseStatement, 0));
        std::string courseTitle = reinterpret_cast<const char*>(sqlite3_column_text(courseStatement, 1));

        std::vector<std::string> prerequisites;
        const char* prereqSql = "SELECT prerequisiteNumber FROM Prerequisites WHERE courseNumber = ? ORDER BY prerequisiteNumber;";
        sqlite3_stmt* prereqStatement = nullptr;

        if (sqlite3_prepare_v2(database, prereqSql, -1, &prereqStatement, nullptr) != SQLITE_OK) {
            messages.push_back("Database error: Could not prepare prerequisite query.");
            sqlite3_finalize(courseStatement);
            return false;
        }

        if (!bindText(prereqStatement, 1, courseNumber, messages)) {
            sqlite3_finalize(prereqStatement);
            sqlite3_finalize(courseStatement);
            return false;
        }

        while (sqlite3_step(prereqStatement) == SQLITE_ROW) {
            prerequisites.emplace_back(reinterpret_cast<const char*>(sqlite3_column_text(prereqStatement, 0)));
        }

        sqlite3_finalize(prereqStatement);
        loadedManager.addCourse(Course(courseNumber, courseTitle, prerequisites));
    }

    sqlite3_finalize(courseStatement);

    if (loadedManager.empty()) {
        messages.push_back("Database contains no course records.");
        return false;
    }

    manager = loadedManager;
    messages.push_back("Database load completed successfully. " + std::to_string(manager.getCoursesSorted().size()) + " course(s) loaded.");
    return true;
}

bool DatabaseManager::upsertCourse(const Course& course, std::vector<std::string>& messages) {
    if (!initializeSchema(messages)) {
        return false;
    }

    if (course.getNumber().empty() || course.getTitle().empty()) {
        messages.push_back("Validation error: Course number and title are required.");
        return false;
    }

    const char* courseSql = "INSERT OR REPLACE INTO Courses(courseNumber, courseTitle) VALUES(?, ?);";
    sqlite3_stmt* courseStatement = nullptr;

    if (sqlite3_prepare_v2(database, courseSql, -1, &courseStatement, nullptr) != SQLITE_OK) {
        messages.push_back("Database error: Could not prepare course insert statement.");
        return false;
    }

    bool success = bindText(courseStatement, 1, StringUtils::toUpper(course.getNumber()), messages)
        && bindText(courseStatement, 2, course.getTitle(), messages)
        && sqlite3_step(courseStatement) == SQLITE_DONE;

    sqlite3_finalize(courseStatement);

    if (!success) {
        messages.push_back("Database error: Could not save course " + course.getNumber() + ".");
        return false;
    }

    const char* deletePrereqSql = "DELETE FROM Prerequisites WHERE courseNumber = ?;";
    sqlite3_stmt* deleteStatement = nullptr;

    if (sqlite3_prepare_v2(database, deletePrereqSql, -1, &deleteStatement, nullptr) != SQLITE_OK) {
        messages.push_back("Database error: Could not prepare prerequisite cleanup statement.");
        return false;
    }

    success = bindText(deleteStatement, 1, StringUtils::toUpper(course.getNumber()), messages)
        && sqlite3_step(deleteStatement) == SQLITE_DONE;
    sqlite3_finalize(deleteStatement);

    if (!success) {
        messages.push_back("Database error: Could not update prerequisite records for " + course.getNumber() + ".");
        return false;
    }

    const char* prereqSql = "INSERT INTO Prerequisites(courseNumber, prerequisiteNumber) VALUES(?, ?);";

    for (const std::string& prerequisite : course.getPrerequisites()) {
        sqlite3_stmt* prereqStatement = nullptr;
        if (sqlite3_prepare_v2(database, prereqSql, -1, &prereqStatement, nullptr) != SQLITE_OK) {
            messages.push_back("Database error: Could not prepare prerequisite insert statement.");
            return false;
        }

        success = bindText(prereqStatement, 1, StringUtils::toUpper(course.getNumber()), messages)
            && bindText(prereqStatement, 2, StringUtils::toUpper(prerequisite), messages)
            && sqlite3_step(prereqStatement) == SQLITE_DONE;

        sqlite3_finalize(prereqStatement);

        if (!success) {
            messages.push_back("Database error: Could not save prerequisite " + prerequisite + ".");
            return false;
        }
    }

    return true;
}

bool DatabaseManager::deleteCourse(const std::string& courseNumber, std::vector<std::string>& messages) {
    if (!initializeSchema(messages)) {
        return false;
    }

    const std::string normalizedCourse = StringUtils::toUpper(StringUtils::trim(courseNumber));
    if (normalizedCourse.empty()) {
        messages.push_back("Validation error: Course number cannot be empty.");
        return false;
    }

    const char* deletePrereqSql = "DELETE FROM Prerequisites WHERE prerequisiteNumber = ?;";
    sqlite3_stmt* prereqStatement = nullptr;
    if (sqlite3_prepare_v2(database, deletePrereqSql, -1, &prereqStatement, nullptr) != SQLITE_OK) {
        messages.push_back("Database error: Could not prepare prerequisite delete statement.");
        return false;
    }

    bool success = bindText(prereqStatement, 1, normalizedCourse, messages)
        && sqlite3_step(prereqStatement) == SQLITE_DONE;
    sqlite3_finalize(prereqStatement);

    if (!success) {
        messages.push_back("Database error: Could not remove related prerequisite entries.");
        return false;
    }

    const char* deleteCourseSql = "DELETE FROM Courses WHERE courseNumber = ?;";
    sqlite3_stmt* courseStatement = nullptr;
    if (sqlite3_prepare_v2(database, deleteCourseSql, -1, &courseStatement, nullptr) != SQLITE_OK) {
        messages.push_back("Database error: Could not prepare course delete statement.");
        return false;
    }

    success = bindText(courseStatement, 1, normalizedCourse, messages)
        && sqlite3_step(courseStatement) == SQLITE_DONE;
    const int rowsChanged = sqlite3_changes(database);
    sqlite3_finalize(courseStatement);

    if (!success || rowsChanged == 0) {
        messages.push_back("Course not found in database: " + normalizedCourse + ".");
        return false;
    }

    messages.push_back("Deleted " + normalizedCourse + " from the database.");
    return true;
}

bool DatabaseManager::executeStatement(const std::string& sql, std::vector<std::string>& messages) {
    char* errorMessage = nullptr;
    if (sqlite3_exec(database, sql.c_str(), nullptr, nullptr, &errorMessage) != SQLITE_OK) {
        std::string message = errorMessage == nullptr ? "Unknown database error." : errorMessage;
        messages.push_back("Database error: " + message);
        sqlite3_free(errorMessage);
        return false;
    }
    return true;
}

bool DatabaseManager::bindText(sqlite3_stmt* statement, int index, const std::string& value, std::vector<std::string>& messages) const {
    if (sqlite3_bind_text(statement, index, value.c_str(), -1, SQLITE_TRANSIENT) != SQLITE_OK) {
        messages.push_back("Database error: Could not bind text parameter.");
        return false;
    }
    return true;
}

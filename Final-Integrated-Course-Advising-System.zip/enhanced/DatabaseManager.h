#ifndef DATABASE_MANAGER_H
#define DATABASE_MANAGER_H

#include "Course.h"
#include "CourseManager.h"
#include <sqlite3.h>
#include <string>
#include <vector>

/**
 * Manages SQLite database connectivity, schema creation, and course persistence.
 * Uses prepared statements to reduce SQL injection risk and support secure data handling.
 */
class DatabaseManager {
public:
    explicit DatabaseManager(std::string databaseFile = "courses.db");
    ~DatabaseManager();

    bool open(std::vector<std::string>& messages);
    void close();
    bool initializeSchema(std::vector<std::string>& messages);

    bool saveCourses(const CourseManager& manager, std::vector<std::string>& messages);
    bool loadCourses(CourseManager& manager, std::vector<std::string>& messages);
    bool upsertCourse(const Course& course, std::vector<std::string>& messages);
    bool deleteCourse(const std::string& courseNumber, std::vector<std::string>& messages);

private:
    std::string databaseFile;
    sqlite3* database;

    bool executeStatement(const std::string& sql, std::vector<std::string>& messages);
    bool bindText(sqlite3_stmt* statement, int index, const std::string& value, std::vector<std::string>& messages) const;
};

#endif

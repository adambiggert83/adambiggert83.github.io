#include "GraphAnalyzer.h"
#include "StringUtils.h"
#include <sstream>

GraphAnalyzer::GraphAnalyzer(const CourseManager& manager) : courseManager(manager) {}

std::string GraphAnalyzer::buildPrerequisitePath(const std::string& courseNumber) const {
    const std::string normalizedCourse = StringUtils::toUpper(StringUtils::trim(courseNumber));
    std::ostringstream output;

    if (normalizedCourse.empty()) {
        return "Course number cannot be empty.\n";
    }

    if (!courseManager.containsCourse(normalizedCourse)) {
        return "Course not found. Please verify the course number and try again.\n";
    }

    std::unordered_set<std::string> activePath;
    std::unordered_set<std::string> visited;

    output << "Prerequisite Path for " << normalizedCourse << "\n";
    std::string pathText;
    buildPathDepthFirst(normalizedCourse, activePath, visited, 0, pathText);
    output << pathText;

    return output.str();
}

void GraphAnalyzer::buildPathDepthFirst(const std::string& courseNumber,
                                        std::unordered_set<std::string>& activePath,
                                        std::unordered_set<std::string>& visited,
                                        int depth,
                                        std::string& output) const {
    auto course = courseManager.findCourse(courseNumber);

    for (int i = 0; i < depth; ++i) {
        output += "  ";
    }

    if (!course.has_value()) {
        output += "- " + courseNumber + " (missing from catalog)\n";
        return;
    }

    output += "- " + course->getNumber() + ": " + course->getTitle() + "\n";

    if (activePath.count(course->getNumber()) > 0) {
        for (int i = 0; i <= depth; ++i) {
            output += "  ";
        }
        output += "Circular dependency detected; traversal stopped for this branch.\n";
        return;
    }

    if (visited.count(course->getNumber()) > 0) {
        return;
    }

    activePath.insert(course->getNumber());
    visited.insert(course->getNumber());

    for (const std::string& prerequisite : course->getPrerequisites()) {
        const std::string normalizedPrerequisite = StringUtils::toUpper(StringUtils::trim(prerequisite));
        buildPathDepthFirst(normalizedPrerequisite, activePath, visited, depth + 1, output);
    }

    activePath.erase(course->getNumber());
}

bool GraphAnalyzer::hasCircularDependency(const std::string& courseNumber) const {
    const std::string normalizedCourse = StringUtils::toUpper(StringUtils::trim(courseNumber));

    if (normalizedCourse.empty() || !courseManager.containsCourse(normalizedCourse)) {
        return false;
    }

    std::unordered_set<std::string> visited;
    std::unordered_set<std::string> recursionStack;
    return detectCycleDepthFirst(normalizedCourse, visited, recursionStack);
}

std::vector<std::string> GraphAnalyzer::findAllCircularDependencies() const {
    std::vector<std::string> warnings;

    for (const Course& course : courseManager.getCoursesSorted()) {
        if (hasCircularDependency(course.getNumber())) {
            warnings.push_back("Circular prerequisite dependency detected involving " + course.getNumber() + ".");
        }
    }

    return warnings;
}

bool GraphAnalyzer::detectCycleDepthFirst(const std::string& courseNumber,
                                          std::unordered_set<std::string>& visited,
                                          std::unordered_set<std::string>& recursionStack) const {
    const std::string normalizedCourse = StringUtils::toUpper(StringUtils::trim(courseNumber));

    if (!courseManager.containsCourse(normalizedCourse)) {
        return false;
    }

    if (recursionStack.count(normalizedCourse) > 0) {
        return true;
    }

    if (visited.count(normalizedCourse) > 0) {
        return false;
    }

    visited.insert(normalizedCourse);
    recursionStack.insert(normalizedCourse);

    auto course = courseManager.findCourse(normalizedCourse);
    if (course.has_value()) {
        for (const std::string& prerequisite : course->getPrerequisites()) {
            if (detectCycleDepthFirst(prerequisite, visited, recursionStack)) {
                return true;
            }
        }
    }

    recursionStack.erase(normalizedCourse);
    return false;
}

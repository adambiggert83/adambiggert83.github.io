#ifndef GRAPH_ANALYZER_H
#define GRAPH_ANALYZER_H

#include "CourseManager.h"
#include <string>
#include <unordered_set>
#include <vector>

/**
 * Performs graph-based analysis of course prerequisite relationships.
 * Courses are treated as vertices and prerequisite relationships as directed edges.
 */
class GraphAnalyzer {
public:
    explicit GraphAnalyzer(const CourseManager& manager);

    /**
     * Builds a recursive, depth-first prerequisite pathway for a course.
     */
    std::string buildPrerequisitePath(const std::string& courseNumber) const;

    /**
     * Checks one course and its prerequisite chain for circular dependencies.
     */
    bool hasCircularDependency(const std::string& courseNumber) const;

    /**
     * Checks every loaded course for circular prerequisite relationships.
     */
    std::vector<std::string> findAllCircularDependencies() const;

private:
    const CourseManager& courseManager;

    void buildPathDepthFirst(const std::string& courseNumber,
                             std::unordered_set<std::string>& activePath,
                             std::unordered_set<std::string>& visited,
                             int depth,
                             std::string& output) const;

    bool detectCycleDepthFirst(const std::string& courseNumber,
                               std::unordered_set<std::string>& visited,
                               std::unordered_set<std::string>& recursionStack) const;
};

#endif

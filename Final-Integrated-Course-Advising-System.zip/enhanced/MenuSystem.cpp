#include "MenuSystem.h"
#include "StringUtils.h"
#include <iostream>
#include <limits>
#include <sstream>
#include <string>
#include <vector>

void MenuSystem::run() {
    std::cout << "Welcome to the enhanced course planner.\n";

    int choice = 0;
    do {
        std::cout << "\n1. Load CSV Data Structure\n"
                  << "2. Print Course List\n"
                  << "3. Print Course\n"
                  << "4. Print Advising Summary\n"
                  << "5. Display Full Prerequisite Path\n"
                  << "6. Check Circular Dependencies\n"
                  << "7. Save Loaded Courses to SQLite Database\n"
                  << "8. Load Courses from SQLite Database\n"
                  << "9. Add or Update Course in SQLite Database\n"
                  << "10. Delete Course from SQLite Database\n"
                  << "0. Exit\n"
                  << "What would you like to do? ";

        choice = getMenuChoice();

        switch (choice) {
            case 1:
                loadData();
                break;
            case 2:
                printCourseList();
                break;
            case 3:
                printCourseDetails();
                break;
            case 4:
                printAdvisingSummary();
                break;
            case 5:
                printPrerequisitePath();
                break;
            case 6:
                checkCircularDependencies();
                break;
            case 7:
                saveCoursesToDatabase();
                break;
            case 8:
                loadCoursesFromDatabase();
                break;
            case 9:
                addCourseToDatabase();
                break;
            case 10:
                deleteCourseFromDatabase();
                break;
            case 0:
                std::cout << "Thank you for using the course planner!\n";
                break;
            default:
                std::cout << choice << " is not a valid option. Please select a listed menu option.\n";
        }
    } while (choice != 0);
}

int MenuSystem::getMenuChoice() const {
    int choice = 0;

    while (!(std::cin >> choice)) {
        std::cout << "Invalid input. Please enter a numeric menu option.\n";
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "What would you like to do? ";
    }

    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    return choice;
}

void MenuSystem::loadData() {
    std::string filename;
    std::vector<std::string> messages;

    std::cout << "Enter file name: ";
    std::getline(std::cin, filename);
    filename = StringUtils::trim(filename);

    if (filename.empty()) {
        std::cout << "Error: File name cannot be empty.\n";
        return;
    }

    fileLoader.loadCoursesFromCsv(filename, courseManager, messages);
    printMessages(messages);
}

void MenuSystem::printCourseList() const {
    if (courseManager.empty()) {
        std::cout << "No data loaded. Please load the file first or load courses from the database.\n";
        return;
    }

    std::cout << "Here is the course schedule:\n";
    for (const Course& course : courseManager.getCoursesSorted()) {
        std::cout << course.getNumber() << ", " << course.getTitle() << "\n";
    }
}

void MenuSystem::printCourseDetails() const {
    if (courseManager.empty()) {
        std::cout << "No data loaded. Please load the file first or load courses from the database.\n";
        return;
    }

    std::string courseNumber;
    std::cout << "What course do you want to know about? ";
    std::getline(std::cin, courseNumber);

    auto course = courseManager.findCourse(courseNumber);
    if (!course.has_value()) {
        std::cout << "Course not found. Please verify the course number and try again.\n";
        return;
    }

    std::cout << course->getNumber() << ", " << course->getTitle() << "\n";

    if (course->getPrerequisites().empty()) {
        std::cout << "Prerequisites: None\n";
        return;
    }

    std::cout << "Prerequisites: ";
    for (size_t i = 0; i < course->getPrerequisites().size(); ++i) {
        std::cout << course->getPrerequisites()[i];
        if (i < course->getPrerequisites().size() - 1) {
            std::cout << ", ";
        }
    }
    std::cout << "\n";
}

void MenuSystem::printAdvisingSummary() const {
    if (courseManager.empty()) {
        std::cout << "No data loaded. Please load the file first or load courses from the database.\n";
        return;
    }

    std::string courseNumber;
    std::cout << "Enter a course number for the advising summary: ";
    std::getline(std::cin, courseNumber);

    std::cout << courseManager.buildAdvisingSummary(courseNumber);
}

void MenuSystem::printPrerequisitePath() const {
    if (courseManager.empty()) {
        std::cout << "No data loaded. Please load the file first or load courses from the database.\n";
        return;
    }

    std::string courseNumber;
    std::cout << "Enter a course number to analyze its full prerequisite path: ";
    std::getline(std::cin, courseNumber);

    GraphAnalyzer analyzer(courseManager);
    std::cout << analyzer.buildPrerequisitePath(courseNumber);
}

void MenuSystem::checkCircularDependencies() const {
    if (courseManager.empty()) {
        std::cout << "No data loaded. Please load the file first or load courses from the database.\n";
        return;
    }

    GraphAnalyzer analyzer(courseManager);
    std::vector<std::string> warnings = analyzer.findAllCircularDependencies();

    if (warnings.empty()) {
        std::cout << "No circular prerequisite dependencies were detected.\n";
        return;
    }

    for (const std::string& warning : warnings) {
        std::cout << warning << "\n";
    }
}

void MenuSystem::saveCoursesToDatabase() {
    std::vector<std::string> messages;
    databaseManager.saveCourses(courseManager, messages);
    printMessages(messages);
}

void MenuSystem::loadCoursesFromDatabase() {
    std::vector<std::string> messages;
    databaseManager.loadCourses(courseManager, messages);
    printMessages(messages);
}

void MenuSystem::addCourseToDatabase() {
    std::string courseNumber;
    std::string courseTitle;
    std::string prerequisiteLine;

    std::cout << "Enter course number: ";
    std::getline(std::cin, courseNumber);
    courseNumber = StringUtils::toUpper(StringUtils::trim(courseNumber));

    std::cout << "Enter course title: ";
    std::getline(std::cin, courseTitle);
    courseTitle = StringUtils::trim(courseTitle);

    std::cout << "Enter prerequisites separated by commas, or leave blank if none: ";
    std::getline(std::cin, prerequisiteLine);

    std::vector<std::string> prerequisites;
    if (!StringUtils::trim(prerequisiteLine).empty()) {
        for (const std::string& prerequisite : StringUtils::split(prerequisiteLine, ',')) {
            if (!prerequisite.empty()) {
                prerequisites.push_back(StringUtils::toUpper(prerequisite));
            }
        }
    }

    Course course(courseNumber, courseTitle, prerequisites);
    std::vector<std::string> messages;

    if (databaseManager.upsertCourse(course, messages)) {
        courseManager.addCourse(course);
        messages.push_back("In-memory course list updated with " + courseNumber + ".");
    }

    printMessages(messages);
}

void MenuSystem::deleteCourseFromDatabase() {
    std::string courseNumber;
    std::cout << "Enter course number to delete from the database: ";
    std::getline(std::cin, courseNumber);

    std::vector<std::string> messages;
    if (databaseManager.deleteCourse(courseNumber, messages)) {
        courseManager.removeCourse(courseNumber);
    }

    printMessages(messages);
}

void MenuSystem::printMessages(const std::vector<std::string>& messages) const {
    for (const std::string& message : messages) {
        std::cout << message << "\n";
    }
}

#ifndef MENU_SYSTEM_H
#define MENU_SYSTEM_H

#include "CourseManager.h"
#include "DatabaseManager.h"
#include "FileLoader.h"
#include "GraphAnalyzer.h"

/**
 * Manages console input/output and delegates business logic to other classes.
 */
class MenuSystem {
public:
    void run();

private:
    CourseManager courseManager;
    FileLoader fileLoader;
    DatabaseManager databaseManager;

    int getMenuChoice() const;
    void loadData();
    void printCourseList() const;
    void printCourseDetails() const;
    void printAdvisingSummary() const;
    void printPrerequisitePath() const;
    void checkCircularDependencies() const;
    void saveCoursesToDatabase();
    void loadCoursesFromDatabase();
    void addCourseToDatabase();
    void deleteCourseFromDatabase();
    void printMessages(const std::vector<std::string>& messages) const;
};

#endif

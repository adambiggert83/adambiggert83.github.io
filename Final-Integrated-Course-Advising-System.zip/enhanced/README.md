# CS 499 Course Planner - Database Enhancement

This enhanced C++ course advising system builds on the prior software engineering and algorithms enhancements by adding SQLite database persistence.

## Enhancements Included

- Modular C++ architecture from the software engineering enhancement
- Graph-based prerequisite analysis from the algorithms/data structures enhancement
- SQLite database persistence for the database enhancement
- Relational schema with `Courses` and `Prerequisites` tables
- Prepared SQL statements for safer database operations
- CSV import followed by database save/load functionality
- Add/update and delete operations for database-backed course records

## Build Requirements

- C++17 compiler
- SQLite3 development library

On Debian/Ubuntu-based systems, SQLite development files can be installed with:

```bash
sudo apt-get install libsqlite3-dev
```

## Build

```bash
./build.sh
```

Or manually:

```bash
g++ -std=c++17 main.cpp Course.cpp CourseManager.cpp FileLoader.cpp MenuSystem.cpp StringUtils.cpp GraphAnalyzer.cpp DatabaseManager.cpp -lsqlite3 -o CoursePlanner
```

## Run

```bash
./CoursePlanner
```

## Suggested Test Workflow

1. Choose option 1 and load `sample_courses.csv`.
2. Choose option 2 to verify courses loaded.
3. Choose option 5 to display the full prerequisite path for `CS499`.
4. Choose option 7 to save courses to the SQLite database.
5. Restart the application.
6. Choose option 8 to load courses from the SQLite database.
7. Choose option 2 or 3 to verify persistent data was restored.

The application creates a local `courses.db` SQLite database file when database features are used.

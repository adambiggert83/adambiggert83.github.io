#include <iostream>
#include <fstream>
#include <sstream>
#include <unordered_map>
#include <vector>
#include <algorithm>

using namespace std;

// Struct to hold course data
struct Course {
    string courseNumber;
    string courseName;
    vector<string> prerequisites;
};

unordered_map<string, Course> courseTable;

void LoadData(const string& filename);
void PrintCourseList();
void PrintCourseDetails(const string& courseNumber);
vector<string> Split(const string& line, char delimiter);
string ToUpper(string str);

int main() {
    int choice;
    string filename, courseNumber;

    cout << "Welcome to the course planner.\n";

    do {
        cout << "\n1. Load Data Structure.\n"
             << "2. Print Course List.\n"
             << "3. Print Course.\n"
             << "9. Exit\n"
             << "What would you like to do? ";

        cin >> choice;
        cin.ignore(); // Clear newline from buffer

        switch (choice) {
            case 1:
                cout << "Enter file name: ";
                getline(cin, filename);
                LoadData(filename);
                break;
            case 2:
                cout << "Here is a sample schedule:\n";
                PrintCourseList();
                break;
            case 3:
                cout << "What course do you want to know about? ";
                getline(cin, courseNumber);
                PrintCourseDetails(ToUpper(courseNumber));
                break;
            case 9:
                cout << "Thank you for using the course planner!\n";
                break;
            default:
                cout << choice << " is not a valid option.\n";
        }
    } while (choice != 9);

    return 0;
}

// Load course data from file
void LoadData(const string& filename) {
    ifstream file(filename);
    string line;

    if (!file.is_open()) {
        cout << "Error: Could not open file.\n";
        return;
    }

    courseTable.clear();

    while (getline(file, line)) {
        vector<string> tokens = Split(line, ',');

        if (tokens.size() < 2 || tokens[0].empty() || tokens[1].empty()) {
            continue; // Skip invalid lines
        }

        Course course;
        course.courseNumber = ToUpper(tokens[0]);
        course.courseName = tokens[1];

        for (size_t i = 2; i < tokens.size(); ++i) {
            if (!tokens[i].empty()) {
                course.prerequisites.push_back(ToUpper(tokens[i]));
            }
        }

        courseTable[course.courseNumber] = course;
    }

    cout << "Data loaded successfully.\n";
}

// Print all courses in sorted order
void PrintCourseList() {
    if (courseTable.empty()) {
        cout << "No data loaded. Please load the file first.\n";
        return;
    }

    vector<string> keys;
    for (const auto& pair : courseTable) {
        keys.push_back(pair.first);
    }

    sort(keys.begin(), keys.end());

    for (const string& key : keys) {
        cout << key << ", " << courseTable[key].courseName << "\n";
    }
}

// Print details for a single course
void PrintCourseDetails(const string& courseNumber) {
    auto it = courseTable.find(courseNumber);
    if (it == courseTable.end()) {
        cout << "Course not found.\n";
        return;
    }

    const Course& course = it->second;
    cout << course.courseNumber << ", " << course.courseName << "\n";

    if (course.prerequisites.empty()) {
        return;
    }

    cout << "Prerequisites: ";
    for (size_t i = 0; i < course.prerequisites.size(); ++i) {
        cout << course.prerequisites[i];
        if (i < course.prerequisites.size() - 1) cout << ", ";
    }
    cout << "\n";
}

// Helper to split string by delimiter
vector<string> Split(const string& line, char delimiter) {
    vector<string> tokens;
    string token;
    stringstream ss(line);

    while (getline(ss, token, delimiter)) {
        tokens.push_back(token);
    }

    return tokens;
}

// Convert a string to uppercase for consistent lookup
string ToUpper(string str) {
    for (char& c : str) {
        c = toupper(c);
    }
    return str;
}
